package util

var (
	DB_dsn = "root:123456@tcp(sjzcjx.cn:3307)/go_op_dl?charset=utf8mb4&parseTime=True&loc=Local"
)
