package define

var (
	DefaultPage = "1"
	DefaultSize = "10"
)
