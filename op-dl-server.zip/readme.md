go-Gin web服务端框架

go get -u github.com/gin-gonic/gin

github:https://github.com/gin-gonic/gin

文档:https://gin-gonic.com/zh-cn/docs/

Gen 代码生成器

go go get -u gorm.io/gen
go get -u gorm.io/driver/mysql

github:https://github.com/go-gorm/gen

文档:https://gorm.io/zh_CN/gen/gen_tool.html

gen参考:https://blog.csdn.net/kuangshp128/article/details/131250405

gin-swagger  API

go get -u github.com/swaggo/swag/cmd/swag

go install github.com/swaggo/swag/cmd/swag@latest

go get -u github.com/swaggo/gin-swagger

go get -u github.com/swaggo/files

github:https://github.com/swaggo/gin-swagger

访问地址:http://localhost:8080/swagger/index.html